//
//  CountryCellController.swift
//  CurrencyConverter
//
//  Created by Rui Pedro Garcia da Costa on 07/04/2021.
//

import UIKit

class CountryCellController: UITableViewCell {
    
    //Outlet dos componentes
    @IBOutlet weak var checkImageView: UIImageView!
    @IBOutlet weak var flagImageView: UIImageView!
    @IBOutlet weak var currencyNameLabel: UILabel!
    @IBOutlet weak var currencyCodeLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
