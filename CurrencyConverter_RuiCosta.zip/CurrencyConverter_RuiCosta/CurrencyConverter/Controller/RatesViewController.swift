//
//  RatesViewController.swift
//  CurrencyConverter
//
//  Created by Rui Pedro Garcia da Costa on 07/04/2021.
//

import UIKit
import Kingfisher

class RatesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    //Declaração das propriedades e Outlets
    var rates: [RatesModel] = [RatesModel]()
    @IBOutlet weak var currencyNameLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var currencyCodeLabel: UILabel!
    var baseCurrency: CountryModel?
    let userDefaults = UserDefaults.standard
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        //Limpar o array
        self.rates = [RatesModel]()
        
        //User Defaults para guardar o a ultima moeda escolhida pelo user (não funciona não sei porquê)
        //Apesar de alterar os valores sempre que se executa o programe ele tem USD por defeito, não percebo porquê
        userDefaults.setValue(baseCurrency?.currencyCode ?? "USD", forKey:"default")

        
        //Declaração dos protocolos da tableView
        tableView.delegate = self
        tableView.dataSource = self
        
        //Registar a cell costumizada
        self.tableView.register(UINib (nibName: "RatesCellController", bundle: nil), forCellReuseIdentifier: "ratesCell")
        
        //Invocar o método que devolver as "rates"
        Networking.getRates(userDefaults.string(forKey: "default"), withCompletion: { jsonResponse in
            if let jsonResponse = jsonResponse {
                
                //Percorrer o dicionário da resposta
                for (key, value) in jsonResponse
                {
                    //Variável Auxiliar
                    let valor:NSNumber = value as! NSNumber
                    
                    //Invocar o método que devolve as informações sobre 1 pais para cada moeda para capturar o url da bandeira
                    Networking.getCountries(key.description, withCompletion: { country in
                        if let country = country {
                            
                            //Variável Auxiliar
                            let ratesModel = RatesModel()
                            
                            //Atribuir valores ao elemento ratesModel
                            ratesModel.flagPng = country.flagPng
                            ratesModel.currencyName = country.currencyName
                            ratesModel.currencyCode = key.description
                            ratesModel.currencyValue = valor.stringValue
                            let date: Double = Date().timeIntervalSinceReferenceDate
                            ratesModel.timeStamp = Date(timeIntervalSinceReferenceDate: date)
                            
                            //Atribuir os valores aos componentes da View
                            if (key.description == (self.userDefaults.string(forKey: "default")!))
                            {
                                self.currencyNameLabel.text = country.currencyName
                                self.currencyCodeLabel.text = key.description
                                
                                let url = URL(string: country.flagPng)
                                self.imageView.kf.setImage(with: url)
                            }
                            
                            //Adicionaar o elemento a um array
                            self.rates.append(ratesModel)
                            
                            DispatchQueue.main.async {
                                //Reload da tableView
                                self.tableView.reloadData()
                            }
                        }
                    })
                }
            }
        })
        
    }
    
    //Refresh da TableView com batota
    @IBAction func refreshPressed(_ sender: UIBarButtonItem) {
        
        //Limpar o array
        self.rates = [RatesModel]()
        
        //Invocar o método que devolver as "rates"
        Networking.getRates(userDefaults.string(forKey: "default"), withCompletion: { jsonResponse in
            if let jsonResponse = jsonResponse {
                
                //Percorrer o dicionário da resposta
                for (key, value) in jsonResponse
                {
                    //Variável Auxiliar
                    let valor:NSNumber = value as! NSNumber
                    
                    //Invocar o método que devolve as informações sobre 1 pais para cada moeda para capturar o url da bandeira
                    Networking.getCountries(key.description, withCompletion: { country in
                        if let country = country {
                            
                            //Variável Auxiliar
                            let ratesModel = RatesModel()
                            
                            //Atribuir valores ao elemento ratesModel
                            ratesModel.flagPng = country.flagPng
                            ratesModel.currencyName = country.currencyName
                            ratesModel.currencyCode = key.description
                            ratesModel.currencyValue = valor.stringValue
                            let date: Double = Date().timeIntervalSinceReferenceDate
                            ratesModel.timeStamp = Date(timeIntervalSinceReferenceDate: date)
                            
                            //Atribuir os valores aos componentes da View
                            if (key.description == (self.userDefaults.string(forKey: "default")!))
                            {
                                self.currencyNameLabel.text = country.currencyName
                                self.currencyCodeLabel.text = key.description
                                
                                let url = URL(string: country.flagPng)
                                self.imageView.kf.setImage(with: url)
                            }
                            
                            //Adicionaar o elemento a um array
                            self.rates.append(ratesModel)
                            
                            DispatchQueue.main.async {
                                //Reload da tableView
                                self.tableView.reloadData()
                            }
                        }
                    })
                }
            }
        })
    }
    
    //Definição do número de linhas da tableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return rates.count;
    }
    
    //Definição do conteúdo de cada cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Variáveis auxiliares
        let cell:RatesCellController = tableView.dequeueReusableCell(withIdentifier: "ratesCell", for: indexPath) as! RatesCellController
        let rates: RatesModel = self.rates[indexPath.row]
        
        //Atribuir valores aos componentes da cell
        cell.bigCurrencyCodeLabel.text = rates.currencyCode
        cell.currencyNameLabel.text = rates.currencyName
        cell.currencyValueLabel.text = rates.currencyValue
        let formatter3 = DateFormatter()
        formatter3.dateFormat = "HH:mm E, d MMM y"
        cell.dateLabel.text = formatter3.string(from: rates.timeStamp)
        cell.littleCurrencyCodeLabel.text = rates.currencyCode
        let url = URL(string: rates.flagPng)
        cell.flagImageView.kf.setImage(with: url)
        
        //retornar a cell
        return cell
    }
    
    //Fixar o tamanho da cell para 70 pontos
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70;
    }
}
