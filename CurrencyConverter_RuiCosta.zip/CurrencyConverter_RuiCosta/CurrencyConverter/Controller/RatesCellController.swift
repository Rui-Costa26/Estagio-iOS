//
//  RatesCellController.swift
//  CurrencyConverter
//
//  Created by Rui Pedro Garcia da Costa on 07/04/2021.
//

import UIKit

class RatesCellController: UITableViewCell {

    //Declaração dos outlets
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var currencyValueLabel: UILabel!
    @IBOutlet weak var littleCurrencyCodeLabel: UILabel!
    @IBOutlet weak var bigCurrencyCodeLabel: UILabel!
    @IBOutlet weak var flagImageView: UIImageView!
    @IBOutlet weak var currencyNameLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    //Adicionar espaços entre as cells
    override func layoutSubviews() {
        super.layoutSubviews()

        contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 10, left: 0, bottom: 10, right: 0))
    }
    
}
