//
//  CountryViewController.swift
//  CurrencyConverter
//
//  Created by Rui Pedro Garcia da Costa on 06/04/2021.
//

import UIKit

class CountryViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    //Declaração de propriedades
    @IBOutlet weak var tableView: UITableView!
    var countriesWithCode: [CountryModel] = [CountryModel]()
    var rates: [RatesModel] = [RatesModel]()
    var firstCurrencyCode = ""
    var secondCurrencyCode = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Definir o uso dos protocolos na tableView
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        //Registar a cell costumizada
        self.tableView.register(UINib (nibName: "CountryCellController", bundle: nil), forCellReuseIdentifier: "countryCell")
        
        
        //Invocar o método que devolve as "rates" definindo posteriormente uma Closure
        Networking.getRates("USD", withCompletion: { jsonResponse in
            if let jsonResponse = jsonResponse {
                
                //Percorrer o dícionário da resposta
                for (key, value) in jsonResponse
                {
                    //Variável auxiliar
                    let valor:NSNumber = value as! NSNumber
                    
                    //Invocar o método que devolve infos sobre um país para cada código de moeda
                    Networking.getCountries(key.description, withCompletion: { country in
                        if let country = country {
                            
                            //Variável Auxiliar
                            let ratesModel = RatesModel()
                            
                            //Atribuir valores ao objeto ratesModel
                            ratesModel.flagPng = country.flagPng
                            ratesModel.currencyName = country.currencyName
                            ratesModel.currencyCode = key.description
                            ratesModel.currencyValue = valor.stringValue
                            
                            //Capturar a data no momento do pedido
                            let date: Double = Date().timeIntervalSinceReferenceDate
                            ratesModel.timeStamp = Date(timeIntervalSinceReferenceDate: date)

                            //Adicionar o elemento ao array de elementos
                            self.rates.append(ratesModel)
                            
                            //Variável auxiliar
                            let countryModel = CountryModel()
                            
                            //Atribuir valores ao objeto countryModel
                            countryModel.countryFlagPng = country.flagPng
                            countryModel.currency = country.currencyName
                            countryModel.currencyCode = key.description
                            
                            //Adicionar o elemento ao array de elementor
                            self.countriesWithCode.append(countryModel)
                            
                            DispatchQueue.main.async {
                                //Fazer reload da tableView
                                self.tableView .reloadData()
                            }
                        }
                    })
                }
            }
        })
    }
    
    
    //Definir o número de linhas da TableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.countriesWithCode.count;
    }
    
    //Definir o conteúdo de cada cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Instanciar a cell
        let cell:CountryCellController = tableView.dequeueReusableCell(withIdentifier: "countryCell", for: indexPath) as! CountryCellController
        
        //Variável auxiliar
        let country: CountryModel = self.countriesWithCode[indexPath.row]
        
        //Atribuir valores aos elementos da cell
        cell.currencyCodeLabel.text = country.currencyCode
        let url = URL(string: country.countryFlagPng)
        cell.flagImageView.kf.setImage(with: url)
        cell.currencyNameLabel.text = country.currency
        cell.checkImageView.isHidden = true
        if (firstCurrencyCode == self.countriesWithCode[indexPath.row].currencyCode || secondCurrencyCode == self.countriesWithCode[indexPath.row].currencyCode)
        {
            cell.checkImageView.isHidden = false
        }
        
        //retornar a cell preenchida
        return cell
    }
    
    //Definir a altura de 50 pontos para cada linha
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50;
    }
    
    //Atibuir ações quando uma cell é selecionada
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //Inicializar um country
        let country = self.countriesWithCode[indexPath.row]
        
        //Inicializar um array de view controllers
        let viewControllers = self.navigationController!.viewControllers as NSArray
        
        //Verificar qual o tipo de View Controller vai ser mostrador
        if let rates = viewControllers[0] as? RatesViewController
        {
            rates.baseCurrency = country
            self.navigationController?.popToViewController(rates, animated: true)
        }
        
        //Verificar qual o tipo de View Controller vai ser mostrador
        if let calculator = viewControllers[0] as? CalculatorViewController
        {
            //Caso tenha recebido um firstCurrencyCode, devolver os dados para o firstCurreny da calculator
            if self.firstCurrencyCode != ""
            {
                //limpar as variáveis
                self.firstCurrencyCode = ""
                self.secondCurrencyCode = ""
                
                //Devolver dados
                calculator.firstCurrency = self.rates[indexPath.row]
                
                //Mostrar a viewController
                self.navigationController?.popToViewController(calculator, animated: true)
                
            }
            
            //Caso tenha recebido um ssecondCurrencyCode, devolver os dados para o secondCurrency da Calculator
            else if self.secondCurrencyCode != ""
            {
                //limpar as variáveis
                self.firstCurrencyCode = ""
                self.secondCurrencyCode = ""
                
                //Devolver dados
                calculator.secondCurrency = self.rates[indexPath.row]
                
                //Mostrar a viewController
                self.navigationController?.popToViewController(calculator, animated: true)
            }
            
            
        }
        
    }
}


