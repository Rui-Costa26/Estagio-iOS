//
//  CalculatorViewController.swift
//  CurrencyConverter
//
//  Created by Rui Pedro Garcia da Costa on 07/04/2021.
//

import UIKit

class CalculatorViewController: UIViewController {

    
    //Definição das propriedades e outlets
    @IBOutlet weak var secondCurrencyTextField: UITextField!
    @IBOutlet weak var firstCurrencyTextfield: UITextField!
    @IBOutlet weak var firstCurrencyCodeLabel: UILabel!
    @IBOutlet weak var firstCurrencyNameLabel: UILabel!
    @IBOutlet weak var secondCurrencyCodeLabel: UILabel!
    @IBOutlet weak var secondCurrencyNameLabel: UILabel!
    var firstCurrency: RatesModel?
    var secondCurrency: RatesModel?
    var dialogMessage = UIAlertController(title: "Error", message: "Something went wrong!", preferredStyle: .alert)
    let ok = UIAlertAction(title: "OK", style: .default, handler:nil)
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.firstCurrency?.currencyCode = "."
        self.secondCurrency?.currencyCode = "."

    }
    
    override func viewWillAppear(_ animated: Bool) {
        //Adicionar botão à alert view
        self.dialogMessage.addAction(self.ok)
        
        
        //Atribuir valores aos componentes da View
        self.firstCurrencyCodeLabel.text = firstCurrency?.currencyCode ?? " "
        self.firstCurrencyNameLabel.text = firstCurrency?.currencyName ?? "Choose a Currency"
        self.secondCurrencyCodeLabel.text = secondCurrency?.currencyCode ?? " "
        self.secondCurrencyNameLabel.text = secondCurrency?.currencyName ?? "Choose a Currency"
    }
    
    //Envio de dados através das segues
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //Caso seja através do primeiro botão
        if segue.identifier == "firstCurrencySegue"
        {
            //Variável auxiliar
            let destination = segue.destination as! CountryViewController
            //Atribuir os dados
            destination.firstCurrencyCode = firstCurrencyCodeLabel.text!
        }
        //Caso seja através do segundo botão
        if segue.identifier == "secondCurrencySegue"
        {
            //Variável auxiliar
            let destination = segue.destination as! CountryViewController
            //Atribuir os dados
            destination.secondCurrencyCode = secondCurrencyCodeLabel.text!
        }
    }
    
    @IBAction func pickSecondCurrencyPressed(_ sender: UIButton) {
    }
    
    @IBAction func pickFirstCurrencyPressed(_ sender: UIButton) {
    }
    
    //Trocar as moedas
    @IBAction func swapPressed(_ sender: UIButton) {
        if let aux = firstCurrency
        {
            //Caso existam 2 moedas
            if (secondCurrency?.currencyCode != "" && firstCurrency?.currencyCode != "")
            {
                //Trocar os valores
                firstCurrency = secondCurrency
                secondCurrency = aux
                
                //Atribuir os valores aos componentes
                self.firstCurrencyCodeLabel.text = firstCurrency?.currencyCode
                self.firstCurrencyNameLabel.text = firstCurrency?.currencyName
                self.secondCurrencyCodeLabel.text = secondCurrency?.currencyCode
                self.secondCurrencyNameLabel.text = secondCurrency?.currencyName
            }
        }
        
    }
    
    //Fazer a conversão
    @IBAction func calculatePressed(_ sender: Any) {
        //Variável auxiliar
        var aux = Float()
        
        //Atribuir os valores às variáveis
        guard let value = self.firstCurrencyTextfield.text
        else
        {
            self.present(dialogMessage, animated: true, completion: nil)
            return
        }
        guard let second = self.secondCurrency?.currencyValue
        else
        {
            self.present(dialogMessage, animated: true, completion: nil)
            return
        }
        guard let first = self.firstCurrency?.currencyValue
        else
        {
            self.present(dialogMessage, animated: true, completion: nil)
            return
        }
        
        //Efetuar o calculo
        aux = ((value as NSString).floatValue * (second as NSString).floatValue) / (first as NSString).floatValue
        
        //Atribuir o valor ao TextField
        secondCurrencyTextField.text = aux.description
    }
}
