//
//  CountryModel.h
//  CurrencyConverter
//
//  Created by Rui Pedro Garcia da Costa on 07/04/2021.
//

#import <Foundation/Foundation.h>

@interface CountryModel : NSObject

//Declaração das propriedades
@property (strong, nonatomic) NSString *currencyCode;
@property (strong, nonatomic) NSString *currency;
@property (strong, nonatomic) NSString *countryFlagPng;

@end

