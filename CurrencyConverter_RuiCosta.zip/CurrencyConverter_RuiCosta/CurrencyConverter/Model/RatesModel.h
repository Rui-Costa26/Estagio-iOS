//
//  RatesModel.h
//  CurrencyConverter
//
//  Created by Rui Pedro Garcia da Costa on 07/04/2021.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RatesModel : NSObject

//Declaração das propriedades
@property (strong, nonatomic) NSString *currencyCode;
@property (strong, nonatomic) NSString *currencyName;
@property (strong, nonatomic) NSString *FlagPng;
@property (strong, nonatomic) NSString *currencyValue;
@property (strong, nonatomic) NSDate *timeStamp;

@end

NS_ASSUME_NONNULL_END
