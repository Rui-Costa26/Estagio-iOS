//
//  Networking.h
//  CurrencyConverter
//
//  Created by Rui Pedro Garcia da Costa on 06/04/2021.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"
#import "Country.h"
#import <UIKit/UIKit.h>



@interface Networking : NSObject

//Definição de propriedades e funções
@property NSMutableArray <Country*> *countries;

+(void)getCountries:(NSString *)code withCompletion:(void (^)(Country*))Block;

+(void)getRates:(NSString *)code withCompletion:(void (^)(NSDictionary *))Block;

@end
