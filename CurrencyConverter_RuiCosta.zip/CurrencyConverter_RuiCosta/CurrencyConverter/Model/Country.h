//
//  Country.h
//  CurrencyConverter
//
//  Created by Rui Pedro Garcia da Costa on 06/04/2021.
//

#import <Foundation/Foundation.h>



@interface Country : NSObject

//Declaração de propriedades
@property (strong, nonatomic) NSString *NativeName;
@property (strong, nonatomic) NSString *CurrencyName;
@property (strong, nonatomic) NSString *FlagPng;

@end

