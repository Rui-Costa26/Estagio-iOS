//
//  RatesModel.m
//  CurrencyConverter
//
//  Created by Rui Pedro Garcia da Costa on 07/04/2021.
//

#import "RatesModel.h"

@implementation RatesModel

@end
