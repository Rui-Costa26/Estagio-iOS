//
//  Networking.m
//  CurrencyConverter
//
//  Created by Rui Pedro Garcia da Costa on 06/04/2021.
//

#import <Foundation/Foundation.h>
#import "Networking.h"

@implementation Networking

//Capturar informação relativa a países através de um código da moeda
+(void)getCountries:(NSString *)code withCompletion:(void (^)(Country*))Block{
    
    //Inicializar variáveis
    Country *country = [[Country alloc] init];
    NSString *requestString = [[NSString alloc] init];
    NSMutableArray <Country*> *countries = [[NSMutableArray alloc] init];
    
    //Configurar o request
    requestString = [NSString stringWithFormat:@"http://countryapi.gear.host/v1/Country/getCountries?pCurrencyCode=%@", code];
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    NSURL *url = [NSURL URLWithString:requestString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
   
    //Efetuar a dataTask
    NSURLSessionDataTask *dataTask = [manager dataTaskWithRequest:request uploadProgress:nil downloadProgress:nil completionHandler:^(NSURLResponse *response, id responseObject, NSError *error)
    {
        //Caso aconteça algum erro
        if (error)
        {
            NSLog(@"Error: %@", error);
        }
        //Em caso de sucesso
        else
        {
            //Retornar para um array de dicionários o conteúdo da keu Response
            NSArray <NSDictionary *> *jsonResponse = [responseObject valueForKey:@"Response"];
            
            //Percorrer os dicionários do array (não havia necessidade de percorrer o array todo uma vez que apenas retornamos o primeiro elemento)
            for (NSDictionary *countrieDict in jsonResponse)
            {
                //Definição do nome do país
                NSString *nativeName = (countrieDict[@"NativeName"] != [NSNull null]) ? countrieDict[@"NativeName"] : @"No Name";
                country.NativeName = nativeName;
                //Definição do nome da moeda
                NSString *currencyName = (countrieDict[@"CurrencyName"] != [NSNull null]) ? countrieDict[@"CurrencyName"] : @"No Currency";
                country.CurrencyName = currencyName;
                //Definição do url da bandeira
                NSString *flag = (countrieDict[@"FlagPng"] != [NSNull null]) ? countrieDict[@"FlagPng"] : @"No Image";
                country.FlagPng = flag;
                
                //Adicionar o objeto ao array
                [countries addObject:country];
            }
            
            //Verificar se o array não está vazio
            if (countries.count != 0)
            {
            //Invocar a closure passando-lhe um objeto, correspondete ao indíce 0 do array
            Block(countries[0]);
            }
        }
    }];
    
    //Continuar a dataTask
    [dataTask resume];
}


//Capturar informação relativa a valores de moeda em relação a uma moeda em específico
+(void)getRates:(NSString *)code withCompletion:(void (^)(NSDictionary *))Block
{
    //Configuração do request
    NSString *requestString = [[NSString alloc] init];
    requestString = [NSString stringWithFormat:@"https://api.exchangerate.host/latest?base=%@", code];
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    NSURL *url = [NSURL URLWithString:requestString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    //Executar a dataTask
    NSURLSessionDataTask *dataTask = [manager dataTaskWithRequest:request uploadProgress:nil downloadProgress:nil completionHandler:^(NSURLResponse *response, id responseObject, NSError *error)
    {
        //Caso aconteça algum erro
        if (error)
        {
            NSLog(@"Error: %@", error);
        }
        //Caso seja bem sucedido
        else
        {
            //Ler o conteúdo da chave "rates" da resposta para um dicionário
            NSDictionary *jsonResponse = [responseObject valueForKey:@"rates"];
            
            //Retornar o dicionário para a Closure
            Block(jsonResponse);
        }
    }];
    
    //Continuar o dataTask
    [dataTask resume];
}

@end
